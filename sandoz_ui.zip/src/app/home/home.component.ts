import { Component, OnInit } from '@angular/core';
import { ActivationEnd, Router } from '@angular/router';
import { UserDataService } from '../services';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  HoldData
  UiData
  bannerImage: any;
  BgColor: any;
  constructor(private userdataService: UserDataService, private router: Router) { }

  ngOnInit(): void {
    this.getJounery();
    this.GetDetails();
  }
  GetDetails() {
    this.userdataService.GetDetails().subscribe((data) => {
      this.UiData = data.standards;
      this.bannerImage = this.UiData.banner_image
      this.UiData = data.standards;
      this.BgColor = this.UiData.LOGIN_PAGE_BG_COLOR
})
  }
getJounery() {
  this.userdataService.GetJounery().subscribe((data) => {
    this.HoldData = data.Program_flow;
    console.log(this.HoldData)
  })
}
status(value, value1) {
  if (value == 'Assigned' && value1 == '1') {
    return 'active';
  }
  else if (value == 'Assigned' && value1 == '0') {
    return 'Not';
  }
  else if (value == 'Inprogress' && value1 == '1') {
    return 'Inprogress';
  }
  else if (value == 'Completed') {
    return 'completed';
  }
}
checkflow(value) {
  if (value == '0') {
    return 'aasigned';
  }
  else if (value == '1') {
    return 'notaasigned';
  }
}
Module(value1, value2, value3, value4, value5) {

  if (value3 == '0') {
    Swal.fire(value5)
  }
  else if (value3 == '1') {
    console.log(value3)
    this.router.navigate(['/showjounery/' + value2, value1, value4, value3, value5 + '']);
  }
}
}
