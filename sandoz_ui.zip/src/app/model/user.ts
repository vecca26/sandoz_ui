export class User {
  success: boolean
  message: string
  token: string

}
// export class UserRegister{
//     success: boolean;
//     message: string;
//     "userData": {
//         fieldCount:number;
//         affectedRows: number;
//         insertId: number;
//         info: null;
//         serverStatus: number;
//         warningStatus: number;
//     }
// }