import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { UserDataService } from '../services';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-page',
  templateUrl: './page.component.html',
  styleUrls: ['./page.component.css']
})
export class PageComponent implements OnInit {
  HoldData
  @ViewChild('myVideo') myVideo: ElementRef;
  UiData: any;
  BgColor: any;
  BgloginColor: any;
  constructor(private userdataService: UserDataService,private sanitizer: DomSanitizer,private router: Router) { }

  ngOnInit(): void {
    this.getJounery();
    this.GetDetails();
  }
  GetDetails() {
    this.userdataService.GetDetails().subscribe((data) => {
      this.UiData = data.standards;
      this.BgColor = this.UiData.LOGIN_PAGE_BG_COLOR
      this.BgloginColor = this.UiData.LOGIN_BOX_COLOR
     

    })
  }
  getJounery() {
    this.userdataService.GetJounery().subscribe((data) => {
      this.HoldData = data.Program_flow;
      console.log(this.HoldData)
    })
  }
  Module(value1, value2, value3, value4,value5) {
    if (value3 == '0') {
      Swal.fire(value5)
    }
    else if (value3 == '1') {
      console.log(value3)
      this.router.navigate(['/showjounery/' + value2, value1, value4,value3,value5 + '']);
    }
  }
  status(value,value1){
    if (value == 'Assigned' && value1 == '1') {
      return 'active';
    }
    else if (value == 'Assigned' && value1 == '0') {
      return 'Not';
    }
    else if (value == 'Inprogress' && value1 == '1') {
      return 'Inprogress';
    }
    else if(value == 'Completed'){
      return 'completed';
    }
    else if(value == 'Not Assigned'){
      return 'Not';
    }
    }
}
