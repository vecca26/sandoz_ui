export const environment = {
  API_URL: 'http://dev.api.sandozcms.dap-health.com/',
  // API_URL :'http://localhost:5065/api/',
  production: true
 
};

